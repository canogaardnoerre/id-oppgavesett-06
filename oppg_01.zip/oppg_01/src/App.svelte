<script>
	
	let filmer = []

	const hentFilmer = async () => {
		const response = await fetch('https://swapi.co/api/films/?results=7')
		const json = await response.json()
		filmer = json.results
	}

	hentFilmer()

</script>

<header>
	<h1>Star Wars-filmer</h1>
</header>

<main>
	
	{#each filmer as film}
		<article>
		<h2>{film.title}</h2>
		<p>{film.opening_crawl}</p>
		</article>
	
	{:else}
	<h2>Laster filmer...</h2>
	{/each}
	
</main>

<style>
	
	*, html{
		font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
		
	}

	header {
		margin: 0;
		padding: 0;
		max-width: 100vw;
		background-image: url(https://media1.tenor.com/images/c2c12717251f6b9867774ee1f0828f40/tenor.gif?itemid=13404771);
		background-size: contain;
	}

	header h1 {
		text-align: center;
		padding: 2rem;
		color: darkgoldenrod;
		font-size: 5rem;
	}
	
	main {
		max-width: 100vw;
		display: grid;
		grid-template-columns: auto auto ;
		gap: 2rem;
		background-color: darkgoldenrod;
		color: black;
		
	}

	h2, p {
		margin: 3rem;
		letter-spacing: 0.2rem;
		line-height: 1.5rem;
		width: 500px;
	}

	
</style>