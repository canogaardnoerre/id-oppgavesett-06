<script>
	
	let guder = []
	let url = "./guder.json"

	const getGuder = async () => {
		const response = await fetch(url)
		const json = await response.json()
		guder = json.results
		console.log(guder)
	}

	getGuder()

</script>

<body>
	<main>
		
		<h1>Guder fra det gamle Egypt</h1>

		<ul>
			
			{#each guder as gud}
			<section>
				<h1>{gud.navn}</h1>
				<p>{gud.info}</p>
			</section>
				
			{:else}
				<p>Laster guder ...</p>
			{/each}	
			
		</ul>
		
	</main>
	
</body>

<style>
	
	* {
		box-sizing: border-box;
		font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
	}
	
	body {
	
		 scroll-behavior: auto;
		 height: 100vh;
		 width: 100vw;	 
	}
	
	main {
		text-align: center;
		padding: 0;
		max-width: 100vw;
		margin: 0;
		display: grid;
		grid-template-columns: auto;
		place-content: center;
		background-image: url(https://cdn.pixabay.com/photo/2016/11/13/20/55/egyptian-1822036_960_720.jpg);
		background-attachment: fixed;
		background-position: center;
		background-repeat: no-repeat;
		background-size: cover;
		transition: 1s ease-in;
	}
	
	h1 {
		margin-top: 4rem;
		padding: 4rem;
		color: seagreen;
		text-align: center;
		font-size: 2.5rem;
	}

	section {
		display: grid;
		grid-template-columns: auto;
		place-content: center;
		height: 100vh;
		width: 100vw;
		gap: 1rem;
		position: relative;
	}
	
	section h1 {
		padding: 1rem;
		font-size: 2rem;
	}
		
	p {
		margin: 0;
		padding: 1rem;
		width: 50vw;
		text-align: center;
	}

</style>