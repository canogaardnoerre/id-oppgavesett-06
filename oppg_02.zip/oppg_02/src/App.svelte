<script>

	let person = 1


	const finnPerson = async () => {
		const response = await fetch(`https://swapi.co/api/people/${person}`)
		const json = await response.json()
		person = json
	}

	finnPerson()
	
	
	</script>

<main>
	
	{#if person}
	<article>
		<h1>{person.name}</h1>	
		<p><b>Height:</b> {person.height}</p>
		<p><b>Mass:</b> {person.mass}</p>
		<p><b>Eye color:</b> <span>{person.eye_color}</span></p>
		<p><b>Birth year:</b> {person.birth_year}</p>
		<p><b>Gender:</b> {person.gender}</p>
	</article>

	{:else}
		<p>Laster person...</p>
	{/if}

</main>

<style>
	
	main {
		text-align: center;
		padding: 0;
		max-width: 100vw;
		height: 100vh;
		margin: 0;
		display: grid;
		grid-template-columns: auto;
		justify-content: center;
		background-color: darkgoldenrod;
		color: black;
		font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
		line-height: 1.5;
		letter-spacing: 0.5;
	}


	h1 {
		padding: 1rem;
		margin-top: 20vh;
		margin-bottom: 5vh;
		border-bottom: 2px solid black;
	}

	span {
		color: rgb(7, 36, 73);
	}

</style>