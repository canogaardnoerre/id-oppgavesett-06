<script>

	
	
	let person = 1



	const velgPerson = async () => {
		const response = await fetch(`https://swapi.co/api/people/${person}/`)
		const json = await response.json()
		person = json
		
		console.log(person)
	}

	velgPerson()

</script>



	<header>
		<div>
			<h2>Velg karakter etter nummer:</h2>
			<!-- <div>
				<label>0</label> <input type="radio" value="0" bind:group={person} on:click={velgPerson}>
				<label>1</label> <input type="radio" value="1" bind:group={person} on:click={velgPerson}>
				<label>2</label> <input type="radio" value="2" bind:group={person} on:click={velgPerson}>
				<label>3</label> <input type="radio" value="3" bind:group={person} on:click={velgPerson}>
				<label>4</label> <input type="radio" value="4" bind:group={person} on:click={velgPerson}>
			</div> -->
			<input type="number" bind:value={person} on:input={velgPerson}>
		</div>
	</header>

<main>

	{#if person}
		<article>
			<h1>{person.name}</h1>
			<p><b>Height:</b> {person.height}</p>
			<p><b>Mass:</b> {person.mass}</p>
			<p><b>Eye color:</b> {person.eye_color}</p>
			<p><b>Birth year:</b> {person.birth_year}</p>
			<p><b>Gender:</b> {person.gender}</p>
		</article>
	
	{:else}
		<p>Laster person...</p>
	{/if}

</main>

<style>
	* {
		font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
	}
	
	header {
		height: 100vh;
		width: 20vw;
		display: grid;
		grid-template-columns: auto;
		place-content: center;
		position: fixed;
		background-color: white;
		color: darkgoldenrod;
		gap: 1rem;
		
	}

	header div {
		display: flex;
		flex-direction: column;
		place-items: center;
		
	}

	header h2 {
		margin-bottom: 2rem;
		padding: 0;
		text-align: center;
	}

	input {
		border: 2px solid darkgoldenrod;
		text-align: center;
		width: 5vw;
		margin: 0;
		padding: 1rem;
	
	}

	input:hover {
		background-color: lightgoldenrodyellow;
	}
	
	main {
		height: 100vh;
		width: 80vw;
		background-color: darkgoldenrod;
		color: black;
		text-align: center;
		padding: 0;
		margin: 0;
		display: grid;
		grid-template-columns: auto;
		place-items: center;
		transition: 1s;
		float: right;
		
	}

	h1 {
		margin-top: 10vh;
		margin-bottom: 5vh;
		padding: 1rem;
		border-bottom: 2px solid black;
	}

	

</style>